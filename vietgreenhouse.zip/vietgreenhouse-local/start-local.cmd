@echo off
setlocal
cd /d "%~dp0"
where php >nul 2>nul
if errorlevel 1 (
  echo PHP 8.1+ was not found on PATH.
  pause
  exit /b 1
)
echo Open http://127.0.0.1:8080/ in your browser.
php -S 127.0.0.1:8080 -t public router.php
pause
