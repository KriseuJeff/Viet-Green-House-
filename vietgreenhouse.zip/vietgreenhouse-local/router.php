<?php
declare(strict_types=1);

$public = realpath(__DIR__ . '/public');
$path = rawurldecode((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH));
$candidate = realpath($public . $path);
if ($candidate && str_starts_with($candidate, $public . DIRECTORY_SEPARATOR)
    && is_file($candidate) && !str_ends_with(strtolower($candidate), '.php')
    && !str_starts_with(basename($candidate), '.')) {
    return false;
}

require $public . '/index.php';
