# Viet Green House

Mở **start-local.cmd**, giữ cửa sổ đó mở và truy cập http://127.0.0.1:8080/. Máy này đã có PHP. Trên máy khác cần PHP 8.1+ trong PATH.

## Cấu trúc backend

- public/index.php nhận yêu cầu, tra cứu đường dẫn và render HTML trên máy chủ. router.php dùng khi chạy với PHP CLI. Apache cần đặt DocumentRoot tại public và bật mod_rewrite cho public/.htaccess.
- app/pages chứa HTML và nội dung công khai lưu từ website gốc. app/routes.json là danh sách URL đã lưu. Hai URL Thiết kế và Thi công giữ nội dung công khai hiện có. Nguồn của hai trang hiện trả về “Không tìm thấy kết quả”.
- app/catalog.json chứa các nhóm và mẫu nội thất. Mỗi mục có name, slug duy nhất và image (đường dẫn ảnh tương đối trong public). Mục lấy từ dự án Viet Green House có thêm project (slug dự án). Khi thêm mục, trang sản phẩm /san-pham/<slug> được tạo tự động.
- app/forms.php kiểm tra và lưu dữ liệu biểu mẫu đăng ký nhận tin, liên hệ vào storage/submissions.jsonl. Dữ liệu được ghi tại máy chạy website. Biểu mẫu liên hệ nhận tệp ảnh JPG, PNG, WebP, GIF hoặc PDF tối đa 2 MB. Tệp được lưu bằng tên ngẫu nhiên trong storage, ngoài thư mục public.
- public/assets, public/thumbs và public/upload chứa tài nguyên frontend và ảnh công khai đã tải. Một số liên kết dịch vụ bên ngoài, như Google Maps và Zalo, cần mạng.

## Đối chiếu với hệ thống đang chạy

GET trang chủ trả về Apache/2, cookie PHPSESSID, và HTML có Bootstrap 4.0.0 cùng jQuery 1.11.1. Trang mẫu mang tên design by Nina. Backend ở đây là mã PHP dựng lại từ hành vi công khai.

Để đối chiếu framework/CMS, admin, schema cơ sở dữ liệu, các chức năng lưu hoặc gửi biểu mẫu thật và dữ liệu chuyên mục, cần source hiện tại kèm bản sao lưu DB hoặc bản export từ hosting. Bản này chạy local. Việc thay website đang chạy cần kiểm tra các thành phần đó và thử di trú trên môi trường riêng.

## Nguồn ảnh danh mục

Các ảnh dưới đây nằm trong public/upload/catalog và được sử dụng theo [Unsplash License](https://unsplash.com/license).

- Đèn thả ánh ấm · Lee Milo ([ảnh gốc](https://unsplash.com/photos/a-modern-pendant-light-fixture-hangs-indoors-uIjVZb9TEDQ))
- Đèn cây góc đọc sách · Robert | Visual Diary ([ảnh gốc](https://unsplash.com/photos/a-modern-floor-lamp-beside-an-orange-armchair-BUj4Gr_eakM))
- Giường đầu bọc màu sáng · Spacejoy ([ảnh gốc](https://unsplash.com/photos/modern-bedroom-with-white-upholstered-bed-RUvW1KGD9a4))
- Giường đầu bọc màu trầm · Alexey Yanchenkov ([ảnh gốc](https://unsplash.com/photos/modern-bedroom-with-dark-bed-o7dHj11ZtwA))
- Vách lam trắng sau tivi · Puscas Adryan ([ảnh gốc](https://unsplash.com/photos/modern-living-room-with-sofa-tv-and-artwork-ykgcjx46Z0o))
- Vách ốp gỗ phòng khách · Caroline Badran ([ảnh gốc](https://unsplash.com/photos/modern-living-room-with-wooden-paneling-O8zjnsfGAY4))
- Tủ thấp vân gỗ · Sophia Baboolal ([ảnh gốc](https://unsplash.com/photos/brown-wooden-sideboard-vbUULTovNaM))
- Bộ bàn ăn gỗ sáng · Costa Live ([ảnh gốc](https://unsplash.com/photos/wooden-dining-table-with-chairs-and-sideboard-W20zuFrrM6Q))
