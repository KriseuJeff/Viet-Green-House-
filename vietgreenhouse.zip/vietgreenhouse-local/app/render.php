<?php
declare(strict_types=1);

function escape(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function loadData(string $name): array
{
    return json_decode(file_get_contents(__DIR__ . '/' . $name . '.json'), true, 512, JSON_THROW_ON_ERROR);
}

function menu(array $entries, string $slug): string
{
    $html = '<ul>';
    foreach ($entries as $path => $name) {
        $current = $slug === $path ? ' aria-current="page"' : '';
        $html .= '<li><a href="/' . escape($path) . '"' . $current . '>' . escape($name) . '</a></li>';
    }
    return $html . '</ul>';
}

function serviceCards(array $services, bool $home): string
{
    $html = $home ? '' : '<div class="page_duan_detail local-service-grid">';
    foreach ($services as $path => $service) {
        $title = escape($service['name']);
        $image = escape($service['image']);
        $picture = '<img class="d-block w-100" src="' . $image . '" alt="">';
        $html .= '<a class="' . ($home ? 'd-block img_hover' : 'd-block') . '" href="/' . escape($path) . '">'
            . ($home ? $picture : '<picture class="d-block img_hover">' . $picture . '</picture>')
            . '<h2>' . $title . '</h2></a>';
    }
    return $html . ($home ? '' : '</div>');
}

function categoryTabs(array $catalog): string
{
    $html = '';
    foreach ($catalog as $slug => $category) {
        $html .= '<a href="/' . escape($slug) . '">' . escape($category['name']) . '</a>';
    }
    return $html;
}

function categoryItems(array $items): string
{
    if (!$items) {
        return '<p class="text-center local-empty">Danh mục chưa có sản phẩm.</p>';
    }
    $html = '<div class="product_records local-catalog-grid">';
    foreach ($items as $item) {
        $title = escape($item['name']);
        $url = '/san-pham/' . escape($item['slug']);
        $image = '/' . escape(ltrim($item['image'], '/'));
        $html .= '<div class="item_records"><a class="d-block scale-img img_hover position-relative" href="' . $url . '">'
            . '<img loading="lazy" decoding="async" src="' . $image . '" alt="' . $title . '"></a><h3><a href="' . $url . '">' . $title . '</a></h3>'
            . '<p class="price-product"><a class="price-new" href="' . $url . '">Xem thêm</a></p></div>';
    }
    return $html . '</div>';
}

function homeProductPanels(array $catalog): string
{
    $html = '';
    foreach ($catalog as $slug => $category) {
        $html .= '<div class="local-product-panel" data-category="/' . escape($slug) . '" hidden>'
            . categoryItems($category['items']) . '</div>';
    }
    return $html;
}

function homeProjects(array $pages, mixed $requested): string
{
    $count = count($pages);
    $page = filter_var($requested, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => $count]]) ?: 1;
    $html = '<div class="page_duan_detail">' . $pages[$page - 1] . '</div>'
        . '<ul class="paging-sm pagination justify-content-center mt-3 mb-0">';
    for ($number = 1; $number <= $count; $number++) {
        $activeClass = $number === $page ? ' active' : '';
        $current = $number === $page ? ' aria-current="page"' : '';
        $html .= '<li class="page-item"><a class="page-link' . $activeClass . '"' . $current . ' href="/?du-an=' . $number
            . '#cong-trinh-tieu-bieu">' . $number . '</a></li>';
    }
    return $html . '</ul>';
}
