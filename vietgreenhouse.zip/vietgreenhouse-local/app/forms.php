<?php
declare(strict_types=1);

function renderFormStatus(string $status): string
{
    return $status === '' ? '' : '<p class="alert alert-info" role="status">' . escape($status) . '</p>';
}

function formToken(): string
{
    $_SESSION['csrf'] ??= bin2hex(random_bytes(32));
    return '<input type="hidden" name="_token" value="' . $_SESSION['csrf'] . '">';
}

function storeContactAttachment(array $file, string $storage): ?string
{
    if (($file['error'] ?? null) !== UPLOAD_ERR_OK || !is_string($file['tmp_name'] ?? null)
        || !is_int($file['size'] ?? null) || $file['size'] < 1 || $file['size'] > 2 * 1024 * 1024
        || !is_uploaded_file($file['tmp_name'])) {
        return null;
    }
    $image = @getimagesize($file['tmp_name']);
    $extension = match ($image['mime'] ?? null) {
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
        default => file_get_contents($file['tmp_name'], false, null, 0, 5) === '%PDF-' ? 'pdf' : null,
    };
    if ($extension === null) {
        return null;
    }
    $name = 'attachment-' . bin2hex(random_bytes(16)) . '.' . $extension;
    return move_uploaded_file($file['tmp_name'], $storage . $name) ? $name : null;
}

function recordSubmission(string $slug): string
{
    $token = $_POST['_token'] ?? null;
    if (!is_string($token) || !isset($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $token)) {
        return 'Phiên biểu mẫu đã hết hạn. Vui lòng thử lại.';
    }
    $fields = $slug === ''
        ? ['ten-newsletter' => 300, 'diachi-newsletter' => 700, 'dienthoai-newsletter' => 45, 'email-newsletter' => 254, 'noidung-newsletter' => 10000]
        : ['ten' => 300, 'diachi' => 700, 'dienthoai' => 45, 'email' => 254, 'tieude' => 500, 'noidung' => 10000];
    $emailField = $slug === '' ? 'email-newsletter' : 'email';
    $phoneField = $slug === '' ? 'dienthoai-newsletter' : 'dienthoai';
    $entry = ['type' => $slug === '' ? 'newsletter' : 'contact', 'received_at' => gmdate(DATE_ATOM)];
    foreach ($fields as $field => $limit) {
        $raw = $_POST[$field] ?? null;
        if (!is_string($raw)) {
            return 'Vui lòng nhập đầy đủ thông tin.';
        }
        $value = trim($raw);
        if ($value === '' || strlen($value) > $limit || !preg_match('//u', $value)) {
            return 'Vui lòng kiểm tra lại độ dài và nội dung của các trường.';
        }
        $entry[$field] = $value;
    }
    if (!filter_var($entry[$emailField], FILTER_VALIDATE_EMAIL) || !preg_match('/^[+0-9 ().-]{7,30}$/D', $entry[$phoneField])) {
        return 'Vui lòng kiểm tra email và số điện thoại.';
    }
    $storage = dirname(__DIR__) . '/storage/';
    $file = $slug === 'lien-he' ? ($_FILES['file'] ?? []) : [];
    $attachment = null;
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
        $attachment = storeContactAttachment($file, $storage);
        if ($attachment === null) {
            return 'Tệp đính kèm phải là ảnh JPG, PNG, WebP, GIF hoặc PDF và tối đa 2 MB.';
        }
        $entry['attachment'] = $attachment;
    }
    $line = json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR) . PHP_EOL;
    $saved = @file_put_contents($storage . 'submissions.jsonl', $line, FILE_APPEND | LOCK_EX);
    if ($saved !== strlen($line)) {
        if ($attachment !== null) {
            unlink($storage . $attachment);
        }
        return 'Chưa lưu được thông tin. Vui lòng thử lại.';
    }
    unset($_SESSION['csrf']);
    return 'Đã lưu thông tin trong bản chạy thử.';
}
