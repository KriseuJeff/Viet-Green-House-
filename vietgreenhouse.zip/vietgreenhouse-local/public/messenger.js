(() => {
    const widget = document.getElementById('messages-facebook');
    const toggle = widget.querySelector('button');
    const panel = widget.querySelector('#local-messenger-panel');

    function setOpen(open) {
        panel.hidden = !open;
        panel.classList.toggle('open', open);
        toggle.setAttribute('aria-expanded', String(open));
        toggle.setAttribute('aria-label', open ? 'Đóng Messenger' : 'Mở Messenger');
    }

    toggle.addEventListener('click', () => setOpen(panel.hidden));
    widget.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !panel.hidden) {
            setOpen(false);
            toggle.focus();
        }
    });
})();

