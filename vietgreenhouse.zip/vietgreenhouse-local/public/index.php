<?php
declare(strict_types=1);

require __DIR__ . '/../app/render.php';
require __DIR__ . '/../app/forms.php';

$slug = trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($slug === 'tu') {
    header('Location: /tu-ke', true, 301);
    exit;
}

$catalog = loadData('catalog');
$item = null;
$itemCategory = null;
if (str_starts_with($slug, 'san-pham/')) {
    $itemSlug = substr($slug, strlen('san-pham/'));
    foreach ($catalog as $categoryKey => $entry) {
        foreach ($entry['items'] as $candidate) {
            if ($candidate['slug'] === $itemSlug) {
                $item = $candidate;
                $itemCategory = $categoryKey;
                break 2;
            }
        }
    }
}
if ($item !== null) {
    $slug = 'catalog-item';
}

$routes = loadData('routes');
if ($slug === '404' || ($item === null && !in_array($slug, $routes, true))) {
    http_response_code(404);
    $slug = '404';
}
header('Content-Type: text/html; charset=utf-8');
$hasForm = in_array($slug, ['', 'lien-he'], true);
if ($hasForm) {
    session_start(['cookie_httponly' => true, 'cookie_samesite' => 'Lax', 'cookie_secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off']);
}
if ($method === 'POST' && $hasForm) {
    $_SESSION['form-status'] = recordSubmission($slug);
    header('Location: /' . $slug, true, 303);
    exit;
}
if (!in_array($method, ['GET', 'HEAD'], true)) {
    http_response_code(405);
    header('Allow: GET, HEAD');
    exit;
}
$status = $_SESSION['form-status'] ?? '';
if ($hasForm) {
    unset($_SESSION['form-status']);
}

$services = [
    'thiet-ke-kien-truc-noi-that' => 'Thiết kế kiến trúc - Nội thất',
    'thi-cong-phan-tho-hoan-thien' => 'Thi công phần thô - Hoàn thiện',
    'trang-tri-noi-that' => 'Trang trí nội thất',
    'bao-hanh-bao-tri' => 'Bảo hành, bảo trì',
];
$images = loadData('service-images');
$serviceEntries = [];
foreach ($services as $path => $name) {
    $serviceEntries[$path] = ['name' => $name, 'image' => $images[$path]];
}
$catalogMenu = array_column($catalog, 'name');
$catalogMenu = array_combine(array_keys($catalog), $catalogMenu);
$category = $catalog[$slug] ?? null;

$map = file_get_contents(__DIR__ . '/../app/map.html');
$replacements = [
    '<div id="footer-map"></div>' => '<div id="footer-map">' . $map . '</div>',
    '<!--SITE-MAP-->' => $map,
    '<div id="messages-facebook"></div>' => file_get_contents(__DIR__ . '/../app/messenger.html'),
    '<!--PRODUCT-MENU-->' => menu($catalogMenu, $slug),
    '<!--SERVICE-MENU-->' => menu($services, $slug),
];
if ($slug === '') {
    $replacements += [
        '<!--HOME-PROJECTS-->' => homeProjects(loadData('home-projects'), $_GET['du-an'] ?? 1),
        '<!--HOME-SERVICES-->' => serviceCards($serviceEntries, true),
        '<!--PRODUCT-TABS-->' => categoryTabs($catalog),
        '<!--PRODUCT-PANELS-->' => homeProductPanels($catalog),
        '<!--FORM-NEWSLETTER-->' => formToken(),
    ];
}
if ($slug === 'lien-he') {
    $replacements['<!--FORM-CONTACT-->'] = formToken();
}
$replacements += [
    '<!--FORM-STATUS-->' => renderFormStatus($status),
    '<!--CATALOG-->' => categoryItems(array_merge(...array_column($catalog, 'items'))),
    '<!--CATEGORY-->' => $category ? categoryItems($category['items']) : '',
    '<!--SERVICE-LIST-->' => serviceCards($serviceEntries, false),
    '<!--DECOR-SERVICE-->' => '<p>Trao đổi về cách chọn và bố trí đèn, tủ kệ, giường, bàn ghế và vách trang trí theo công năng và phong cách của từng không gian.</p><p><a class="btnXemthem" href="/san-pham">Xem danh mục sản phẩm</a> <a class="btnXemthem" href="/lien-he">Liên hệ tư vấn</a></p>',
    '<!--WARRANTY-SERVICE-->' => '<p>Khi cần kiểm tra, bảo hành hoặc bảo trì, vui lòng cung cấp tên hạng mục, thời điểm bàn giao và tình trạng hiện tại để tiện đối chiếu thông tin công trình.</p><p><a class="btnXemthem" href="/lien-he">Liên hệ bảo hành, bảo trì</a></p>',
    '<!--NOT-FOUND-->' => '<p>Đường dẫn này không tồn tại. <a href="/">Về trang chủ</a></p>',
];
if ($item !== null) {
    $related = array_filter(
        $catalog[$itemCategory]['items'],
        static fn(array $candidate): bool => $candidate['slug'] !== $item['slug']
    );
    $projectLink = isset($item['project'])
        ? '<a href="/' . escape($item['project']) . '">Xem dự án</a>'
        : '';
    $replacements += [
        'CATALOG-ITEM-NAME' => escape($item['name']),
        'CATALOG-ITEM-DESCRIPTION' => escape($item['description'] ?? ''),
        'CATALOG-ITEM-IMAGE' => '/' . escape($item['image']),
        'CATALOG-ITEM-PATH' => '/san-pham/' . escape($item['slug']),
        'CATALOG-CATEGORY-NAME' => escape($catalog[$itemCategory]['name']),
        'CATALOG-CATEGORY-PATH' => '/' . escape($itemCategory),
        '<!--ITEM-PROJECT-->' => $projectLink,
        '<!--RELATED-PRODUCTS-->' => categoryItems($related),
    ];
}
$template = __DIR__ . '/../app/pages/' . ($slug === '' ? 'home' : $slug) . '.html';
echo strtr(file_get_contents($template), $replacements);

