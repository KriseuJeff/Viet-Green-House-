(() => {
    const tabs = Array.from(document.querySelectorAll('.list_sanpham a'));
    const panels = document.querySelectorAll('.local-product-panel');

    function select(tab) {
        tabs.forEach((link) => {
            link.classList.toggle('active', link === tab);
            if (link === tab) link.setAttribute('aria-current', 'true');
            else link.removeAttribute('aria-current');
        });
        panels.forEach((panel) => {
            panel.hidden = panel.dataset.category !== tab.pathname;
            const list = panel.querySelector('.product_records');
            if (panel.hidden || !list || list.classList.contains('owl-loaded') || !window.jQuery?.fn.owlCarousel) return;
            const count = list.children.length;
            window.jQuery(list).addClass('product_records_owl d-block owl-carousel owl-theme').owlCarousel({
                smartSpeed: 250,
                autoplaySpeed: 1000,
                responsive: {
                    0: { items: 2, margin: 15, loop: count > 2, autoplay: count > 2 },
                    1000: { items: 4, margin: 31, loop: count > 4, autoplay: count > 4 },
                },
            });
        });
    }

    function normalClick(event) {
        return event.button === 0 && !event.ctrlKey && !event.metaKey && !event.shiftKey && !event.altKey;
    }

    if (tabs.length && panels.length) {
        tabs.forEach((tab) => tab.addEventListener('click', (event) => {
            if (!normalClick(event)) return;
            event.preventDefault();
            select(tab);
        }));
        select(tabs[0]);
    }

    const projects = document.querySelector('.page_duan');
    let request;
    projects?.addEventListener('click', async (event) => {
        const link = event.target.closest('.paging-sm a[href]');
        if (!link || !normalClick(event)) return;
        event.preventDefault();
        request?.abort();
        request = new AbortController();
        try {
            const response = await fetch(link.href, { signal: request.signal });
            if (!response.ok) throw new Error('Project page unavailable');
            const page = new DOMParser().parseFromString(await response.text(), 'text/html');
            const content = page.querySelector('.page_duan');
            if (!content) throw new Error('Projects missing');
            projects.replaceChildren(...content.childNodes);
            projects.querySelector('[aria-current=page]').focus({ preventScroll: true });
        } catch (error) {
            if (error.name !== 'AbortError') window.location.href = link.href;
        }
    });
})();
